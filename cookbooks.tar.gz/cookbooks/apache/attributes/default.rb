default['app']['server_name'] = "example.com"
