execute "install apache" do
  command "apt-get install apache2 -y" 
end

directory "/var/www/#{node[:app][:server_name]}" do
	owner 'vagrant'
	group 'www-data'
	mode '0755'
	action :create
end

template "/etc/apache2/sites-available/#{node['app'][:server_name]}" do
	source "vhost.conf.erb"
	variables(:server_name => node[:app][:server_name])
end

link "/etc/apache2/sites-enabled/#{node[:app][:server_name]}" do
	to "/etc/apache2/sites-available/#{node[:app][:server_name]}"
end
